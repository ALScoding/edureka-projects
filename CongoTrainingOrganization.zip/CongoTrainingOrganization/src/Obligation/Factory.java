package Obligation;

import Bases.LevelBase;
import Bases.ModeBase;
import Bases.TypeBase;

public interface Factory {

	TypeBase createCourseType(String courseType);

	LevelBase createCourseLevel(String courseLevel);

	ModeBase createCourseMode(String courseMode);

	Feedback createFeedback(String feedback, LevelBase level, TypeBase type, ModeBase mode);
}