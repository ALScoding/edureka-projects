package Obligation;

import Bases.LevelBase;
import Bases.ModeBase;
import Bases.TypeBase;

public class Feedback {
	// course/logistics/delivery and applicability metrics
	// provide different levels of granularity

	public Feedback(LevelBase level, TypeBase type, ModeBase mode) {
		System.out.println("Level selected: " + level.toString() + "\nType selected: " + type.toString()
				+ "\nMode selected: " + mode.toString());
		System.out.println("Applicability: xxxxxxxxxxxxxxxxxxxx");
	}
}