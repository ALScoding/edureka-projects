package Obligation;

import java.util.Scanner;

import Bases.LevelBase;
import Bases.ModeBase;
import Bases.TypeBase;
import trainingTypes.Advanced;

public class RequestManager {

	// for new course requests
	public static void main(String args[]) {

		TypeBase type;
		ModeBase mode;
		LevelBase level;
		Feedback FB;

		System.out.println("Which type of training you would like to request: Advanced, Leadership or Professional?");
		Scanner scanner = new Scanner(System.in);
		String choice = scanner.nextLine();

		Factory factory = new CourseFactory();
		type = factory.createCourseType(choice);

		System.out.println(type.getType());

		type.aboutType(); // You have selected... training. This training type is...

		if (type instanceof Advanced) // if Advanced was the selected type
		{
			level = factory.createCourseLevel("Federal"); // Federal is automatically selected as level
		} else {
			System.out
					.println("Select one of these levels of management: Federal, Provincial, Municipal, or Community?");

			String choice2 = scanner.nextLine();
			level = factory.createCourseLevel(choice2);
			System.out.println(level.getLevel());
			level.aboutLevel(); // You have selected... level.
		}

		System.out.println("Which mode you would like to request: Online, Class Lecture, or Hybrid mode?");
		String choice3 = scanner.nextLine();
		mode = factory.createCourseMode(choice3);
		System.out.println(mode.getMode());
		mode.aboutMode(); // You have selected... mode.

		System.out.println("Would you like to generate a feedback report?");
		String choice4 = scanner.nextLine();
		if (choice4.equalsIgnoreCase("yes")) {
			System.out.println("Generating feedback report for the director...");
			System.out.println("==============================");
			FB = factory.createFeedback(choice4, level, type, mode);
		}
	} // end of main program
}