package Obligation;

import Bases.LevelBase;
import Bases.ModeBase;
import Bases.TypeBase;
import trainingLevels.Community;
import trainingLevels.Federal;
import trainingLevels.Municipal;
import trainingLevels.NewLevel;
import trainingLevels.Provincial;
import trainingModes.ClassLecture;
import trainingModes.Hybrid;
import trainingModes.NewMode;
import trainingModes.Online;
import trainingTypes.Advanced;
import trainingTypes.Leadership;
import trainingTypes.NewType;
import trainingTypes.Professional;

// user will input requests that will match the mentioned choices of type/level/mode regardless of capitalization
// if inputed request does not match the mentioned selections then the input will be treated as a new type/level/mode

public class CourseFactory implements Factory {

	public TypeBase createCourseType(String courseType) {
		TypeBase type = null;

		if (courseType.equalsIgnoreCase("Advanced") || courseType.equalsIgnoreCase("Advanced Leadership"))
			type = new Advanced();
		else if (courseType.equalsIgnoreCase("Leadership"))
			type = new Leadership();
		else if (courseType.equalsIgnoreCase("Professional"))
			type = new Professional();
		else
			type = new NewType(courseType);
		return type;

	}

	public LevelBase createCourseLevel(String courseLevel) {
		LevelBase level = null;

		if (courseLevel.equalsIgnoreCase("Federal"))
			level = new Federal();
		else if (courseLevel.equalsIgnoreCase("Provincial"))
			level = new Provincial();
		else if (courseLevel.equalsIgnoreCase("Municipal"))
			level = new Municipal();
		else if (courseLevel.equalsIgnoreCase("Community"))
			level = new Community();
		else
			level = new NewLevel(courseLevel);
		return level;

	}

	public ModeBase createCourseMode(String courseMode) {
		ModeBase mode = null;

		if (courseMode.equalsIgnoreCase("Class") || courseMode.equalsIgnoreCase("Class Lecture"))
			mode = new ClassLecture();
		else if (courseMode.equalsIgnoreCase("Hybrid"))
			mode = new Hybrid();
		else if (courseMode.equalsIgnoreCase("Online"))
			mode = new Online();
		else
			mode = new NewMode(courseMode);
		return mode;

	}

	public Feedback createFeedback(String feedback, LevelBase level, TypeBase type, ModeBase mode) {
		Feedback FB = null;

		if (feedback.equalsIgnoreCase("Yes") || feedback.equalsIgnoreCase("Y"))
			FB = new Feedback(level, type, mode);
		return FB;
	}
}