package trainingTypes;

import Bases.TypeBase;

public class Leadership extends TypeBase {

	public Leadership() {
		setType("Leadership");
		setDescription("all 4 levels of administrative management.");
	}

	@Override
	public String toString() {
		return "Leadership";
	}
}