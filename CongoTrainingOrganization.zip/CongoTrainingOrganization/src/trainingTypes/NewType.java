package trainingTypes;

import Bases.TypeBase;

public class NewType extends TypeBase {

	public NewType(String type) {
		setType(type);
	}

	@Override
	public String toString() {
		return getType();
	}
}