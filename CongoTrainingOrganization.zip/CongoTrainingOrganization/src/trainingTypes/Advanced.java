package trainingTypes;

import Bases.TypeBase;

public class Advanced extends TypeBase {

	public Advanced() {
		setType("Advanced Leadership");
		setDescription("mainly for the people at Federal level.");
	}

	@Override
	public String toString() {
		return "Advanced";
	}
}