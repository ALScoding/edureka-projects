package trainingTypes;

import Bases.TypeBase;

public class Professional extends TypeBase {

	public Professional() {
		setType("Professional");
		setDescription("all 4 levels of administrative management.");
	}

	@Override
	public String toString() {
		return "Professional";
	}
}