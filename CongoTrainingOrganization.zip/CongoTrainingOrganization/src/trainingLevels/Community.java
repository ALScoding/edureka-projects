package trainingLevels;

import Bases.LevelBase;

public class Community extends LevelBase {

	public Community() {
		setLevel("Community");
	}

	@Override
	public String toString() {
		return "Community";
	}
}