package trainingLevels;

import Bases.LevelBase;

public class NewLevel extends LevelBase {

	public NewLevel(String choice) {
		setLevel(choice);
	}

	@Override
	public String toString() {
		return getLevel();
	}
}