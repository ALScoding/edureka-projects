package trainingLevels;

import Bases.LevelBase;

public class Federal extends LevelBase {

	public Federal() {
		setLevel("Federal");
	}

	@Override
	public String toString() {
		return "Federal";
	}
}