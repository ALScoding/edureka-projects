package trainingLevels;

import Bases.LevelBase;

public class Provincial extends LevelBase {

	public Provincial() {
		setLevel("Provincial");
	}

	@Override
	public String toString() {
		return "Provincial";
	}
}