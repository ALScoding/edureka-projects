package trainingLevels;

import Bases.LevelBase;

public class Municipal extends LevelBase {

	public Municipal() {
		setLevel("Municipal");
	}

	@Override
	public String toString() {
		return "Municipal";
	}
}