package trainingModes;

import Bases.ModeBase;

public class Online extends ModeBase {

	public Online() {
		setMode("Online");
	}

	@Override
	public String toString() {
		return "Online";
	}
}