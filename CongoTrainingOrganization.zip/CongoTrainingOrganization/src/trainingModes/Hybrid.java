package trainingModes;

import Bases.ModeBase;

public class Hybrid extends ModeBase {

	public Hybrid() {
		setMode("Hybrid");
	}

	@Override
	public String toString() {
		return "Hybrid";
	}
}