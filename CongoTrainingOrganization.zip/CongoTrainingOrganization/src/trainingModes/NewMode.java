package trainingModes;

import Bases.ModeBase;

public class NewMode extends ModeBase {

	public NewMode(String mode) {
		setMode(mode);
	}

	@Override
	public String toString() {
		return getMode();
	}
}