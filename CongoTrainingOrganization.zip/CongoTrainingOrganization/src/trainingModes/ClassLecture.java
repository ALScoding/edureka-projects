package trainingModes;

import Bases.ModeBase;

public class ClassLecture extends ModeBase {

	public ClassLecture() {
		setMode("Class Lecture");
	}

	@Override
	public String toString() {
		return "Class Lecture";
	}
}