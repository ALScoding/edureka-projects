package Bases;

abstract public class TypeBase {

	String type;
	String description;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void aboutType() {
		if (type.equals("Advanced Leadership") || type.equals("Leadership") || type.equals("Professional")) {
			System.out.println("You have selected " + type + " training.");
			System.out.println("This training type is available for " + description);
		} else {
			System.out.println("You have entered " + type + " training.");
			System.out.println("This is a new training type that may come up in the future.");
		}
	}
}