package Bases;

abstract public class ModeBase {

	String mode;

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public void aboutMode() {
		if (mode.equals("Class") || mode.equals("Class Lecture") || mode.equals("Hybrid") || mode.equals("Online"))
			System.out.println("You have selected " + mode + " mode of of training delivery.");
		else {
			System.out.println("You have entered " + mode + " mode of of training delivery.");
			System.out.println("This is a new mode that may come up in the future.");
		}
	}
}