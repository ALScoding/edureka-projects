package Bases;

abstract public class LevelBase {

	String level;

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public void aboutLevel() {
		if (level.equals("Federal") || level.equals("Provincial") || level.equals("Municipal")
				|| level.equals("Community"))
			System.out.println("You have selected " + level + " level of administrative management.");
		else {
			System.out.println("You have entered " + level + " level of administrative management.");
			System.out.println("This is a new level that may come up in the future.");
		}
	}
}