-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2018 at 02:52 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_name` (IN `ID` INT, OUT `name` VARCHAR(20))  BEGIN
	SELECT student.name INTO name FROM student WHERE student.ID = ID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendance_log`
--

CREATE TABLE `attendance_log` (
  `card_id` varchar(12) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` enum('N','X') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_log`
--

INSERT INTO `attendance_log` (`card_id`, `time`, `code`) VALUES
('ahhhhd123497', '2018-11-10 08:24:19', 'N'),
('adfehd123497', '2018-11-10 08:24:19', 'N'),
('fdrbhd123437', '2018-11-10 08:24:19', 'N'),
('ah345fgo8449', '2018-11-10 08:24:19', 'N'),
('ahhhhd123497', '2018-11-10 08:24:19', 'X'),
('adfehd123497', '2018-11-10 08:24:19', 'X'),
('fdrbhd123437', '2018-11-10 08:24:20', 'X'),
('ah345fgo8449', '2018-11-10 08:24:20', 'X'),
('ahhhhd123497', '2018-10-01 17:00:00', 'N'),
('adfehd123497', '2018-10-01 17:00:00', 'N'),
('fdrbhd123437', '2018-10-01 17:00:00', 'N'),
('ah345fgo8449', '2018-10-01 17:00:00', 'N'),
('ahhhhd123497', '2018-10-02 00:00:00', 'X'),
('adfehd123497', '2018-10-02 01:00:00', 'X'),
('fdrbhd123437', '2018-10-02 02:00:00', 'X'),
('ah345fgo8449', '2018-10-02 03:00:00', 'X'),
('ahhhhd123497', '2018-10-09 15:05:00', 'N'),
('adfehd123497', '2018-10-09 15:10:00', 'N'),
('fdrbhd123437', '2018-10-09 15:15:00', 'N'),
('ah345fgo8449', '2018-10-09 15:20:00', 'N'),
('ahhhhd123497', '2018-10-09 22:30:00', 'X'),
('adfehd123497', '2018-10-09 23:25:00', 'X'),
('fdrbhd123437', '2018-10-10 00:20:00', 'X'),
('ah345fgo8449', '2018-10-10 01:15:00', 'X'),
('ahhhhd123497', '2018-10-15 22:00:00', 'N'),
('adfehd123497', '2018-10-15 21:00:00', 'N'),
('fdrbhd123437', '2018-10-15 20:00:00', 'N'),
('ah345fgo8449', '2018-10-15 19:00:00', 'N'),
('ahhhhd123497', '2018-10-16 04:30:00', 'X'),
('adfehd123497', '2018-10-16 04:30:00', 'X'),
('fdrbhd123437', '2018-10-16 04:30:00', 'X'),
('ah345fgo8449', '2018-10-16 04:30:00', 'X');

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE `emp` (
  `emp_id` varchar(5) NOT NULL,
  `emp_name` varchar(20) NOT NULL,
  `emp_address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`emp_id`, `emp_name`, `emp_address`) VALUES
('12354', 'S D', 'Bangalore'),
('23477', 'I N', 'Chennai'),
('34252', 'F G', 'Hyderabad'),
('87423', 'T R', 'New Delhi');

-- --------------------------------------------------------

--
-- Table structure for table `emp_access_map`
--

CREATE TABLE `emp_access_map` (
  `card_id` varchar(12) NOT NULL,
  `emp_id` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_access_map`
--

INSERT INTO `emp_access_map` (`card_id`, `emp_id`) VALUES
('ahhhhd123497', '12354'),
('fdrbhd123437', '23477'),
('adfehd123497', '34252'),
('ah345fgo8449', '87423');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `name`) VALUES
(3, 'Karl Pearson'),
(7, 'Alexander Hamilton');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance_log`
--
ALTER TABLE `attendance_log`
  ADD KEY `card_id` (`card_id`);

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `emp_access_map`
--
ALTER TABLE `emp_access_map`
  ADD PRIMARY KEY (`card_id`),
  ADD KEY `emp_id` (`emp_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance_log`
--
ALTER TABLE `attendance_log`
  ADD CONSTRAINT `attendance_log_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `emp_access_map` (`card_id`) ON DELETE CASCADE;

--
-- Constraints for table `emp_access_map`
--
ALTER TABLE `emp_access_map`
  ADD CONSTRAINT `emp_access_map_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `emp` (`emp_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
