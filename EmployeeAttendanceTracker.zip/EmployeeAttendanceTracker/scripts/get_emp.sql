DELIMITER @@;
CREATE PROCEDURE get_emp (emp_id VARCHAR(5) PRIMARY KEY, emp_name VARCHAR(20), emp_address VARCHAR(30))
BEGIN
	SELECT emp.emp_id INTO emp_name FROM emp WHERE emp.emp_id = emp_id;
    SELECT emp.emp_id INTO emp_address FROM emp WHERE emp.address = emp_address;
END;
@@;
DELIMITER;