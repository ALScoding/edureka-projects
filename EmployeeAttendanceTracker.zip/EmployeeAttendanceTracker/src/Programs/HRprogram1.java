package Programs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import CSV.WritetoCSV;

// HR can run a program to query the database and get the attendance 
// for all employees for any day or month.

public final class HRprogram1 {
	private static final Logger logger = Logger.getLogger(HRprogram1.class.getName());

	// properties file where database URL, user & password are stored
	private static final String DB_CONN_FILE = "resources/dbconn.properties";

	public static void main(String[] args) throws Exception {

		// properties file for log4j being used
		PropertyConfigurator.configure("resources\\log4j.properties");

		Properties p = new Properties();
		// Load the properties file
		try {
			p.load(new FileInputStream(new File(DB_CONN_FILE)));
		} catch (IOException e) {
			logger.debug("Error reading " + DB_CONN_FILE);
			e.printStackTrace();
			System.exit(-1);
		}
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		try (Connection conn = DriverManager.getConnection(p.getProperty("url"), p);) {
			// select data from test.attendance_log
			String sqlStmt = "SELECT test.attendance_log.card_id, test.attendance_log.time, test.attendance_log.code FROM test.attendance_log";
			Statement stmt = conn.createStatement();
			List<String> lines = new ArrayList<>();
			lines.add("card_id,time,code");

			ResultSet set = stmt.executeQuery(sqlStmt);
			try {
				System.out.println("Now displaying attendance for all employees...");
				int counter = 0;
				while (set.next()) {
					counter++;
					System.out.println(set.getString(1) + " " + set.getString(2) + " " + set.getString(3));
					lines.add(String.format("%s,%s,%s", set.getString(1), set.getString(2), set.getString(3)));
				}

				logger.debug("Fetched " + counter + " rows.");
			} catch (SQLException e) {
				logger.debug("Query failed.");
				e.printStackTrace();
			}
			System.out.println("\nWould you like save to a CSV file? Enter 1 for yes.");

			Scanner scanner = new Scanner(System.in);
			String choice = scanner.nextLine();
			if (choice.equals("1"))
				WritetoCSV.writeToFile(lines);
			else
				System.out.println("CSV file not created...");
		}
	}
}