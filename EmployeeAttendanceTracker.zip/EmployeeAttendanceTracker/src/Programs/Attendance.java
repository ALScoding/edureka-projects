package Programs;

import java.time.LocalDateTime;

// used by Hrprogram3.java
public class Attendance {
	private String cardId;
	private LocalDateTime time;
	private String code;

	public Attendance(String cardId, LocalDateTime time, String code) {
		super();
		this.cardId = cardId;
		this.time = time;
		this.code = code;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "Attendance [cardId " + cardId + ", time " + time + ", code " + code + "]";
	}
}