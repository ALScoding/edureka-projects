package Programs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import CSV.WritetoCSV;

// HR can run a program to query the database to get the list of employees 
// along with the number of times they had less than 8 hours 

public final class HRprogram3 {
	private static final Logger logger = Logger.getLogger(HRprogram3.class);

	// properties file where database URL, user & password are stored
	private static final String DB_CONN_FILE = "resources/dbconn.properties";

	public static void main(String[] args) throws Exception {

		// properties file for log4j being used
		PropertyConfigurator.configure("resources\\log4j.properties");

		Properties p = new Properties();
		// Load the properties file
		try {
			p.load(new FileInputStream(new File(DB_CONN_FILE)));
		} catch (IOException e) {
			logger.debug("Error reading " + DB_CONN_FILE);
			e.printStackTrace();
			System.exit(-1);
		}
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		try (Connection conn = DriverManager.getConnection(p.getProperty("url"), p);) {
			// select data from test.attendance_log
			String sqlStmt = "SELECT * FROM test.attendance_log order by card_id asc, time asc, code desc;";
			Statement stmt = conn.createStatement();
			List<Attendance> lines = new ArrayList<>();

			ResultSet set = stmt.executeQuery(sqlStmt);
			try {
				System.out.println("Now displaying attendance for all employees...");
				int counter = 0;
				while (set.next()) {
					counter++;
					String cardId = set.getString(1);
					String dateTime = set.getString(2);
					String code = set.getString(3);
					lines.add(new Attendance(cardId,
							LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.S")), code));
					System.out.println(cardId + " " + dateTime + " " + code);
				}

				logger.debug("Fetched " + counter + " rows.");
			} catch (SQLException e) {
				logger.debug("Query failed.");
				e.printStackTrace();
			}

			Scanner scanner = new Scanner(System.in);

			// after all table entries are displayed user has to input the 'from' and 'to'
			// dates in the specified format
			System.out.println("Enter the 'from' date in uuuu-MM-dd");
			String from = scanner.nextLine();
			LocalDate fromDate = LocalDate.parse(from, DateTimeFormatter.ofPattern("uuuu-MM-dd"));
			System.out.println("Enter the 'to' date in uuuu-MM-dd");
			String to = scanner.nextLine();
			LocalDate toDate = LocalDate.parse(to, DateTimeFormatter.ofPattern("uuuu-MM-dd"));

			Map<String, Integer> counter = new HashMap<String, Integer>();
			for (int i = 0; i < lines.size(); i += 2) {
				// Attendance.java is used for this part of the program
				Attendance attendance1 = lines.get(i);
				Attendance attendance2 = lines.get(i + 1);
				LocalDateTime time1 = attendance1.getTime();
				LocalDateTime time2 = attendance2.getTime();
				if (attendance1.getCardId().equals(attendance2.getCardId()) && attendance1.getCode().equals("N")
						&& attendance2.getCode().equals("X")) {
					// if attendance time is between the entered dates
					if (time1.isAfter(fromDate.atStartOfDay()) && time1.isBefore(toDate.plusDays(1).atStartOfDay())) {
						long hours = time1.until(time2, ChronoUnit.HOURS);
						if (hours < 8) {
							Integer integer = counter.get(attendance1.getCardId());
							if (integer == null) {
								integer = 0;
							}
							counter.put("# of times employee " + attendance1.getCardId() + " had <8 hours ", ++integer);
						}
					}
				}
			}

			System.out.println(counter);

			System.out.println("\nWould you like save to a CSV file? Enter 1 for yes.");

			String choice = scanner.nextLine();

			// the results displayed in { } will be written to the CSV file
			if (choice.equals("1")) {
				ArrayList<String> toWrite = new ArrayList<String>();
				for (Entry<String, Integer> E : counter.entrySet()) {
					toWrite.add(E.getKey() + "," + E.getValue());
				}
				WritetoCSV.writeToFile(toWrite);
			} else
				System.out.println("CSV file not created...");
		}
	}
}