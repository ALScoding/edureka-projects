package Programs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import CSV.WritetoCSV;

// HR can run a program to query the database and get the attendance 
// for the month or a day for a particular employee.

public final class HRprogram2 {
	private static final Logger logger = Logger.getLogger(HRprogram2.class.getName());

	// properties file where database URL, user & password are stored
	private static final String DB_CONN_FILE = "resources/dbconn.properties";

	public static void main(String[] args) throws Exception {

		System.out.println("Please enter the card id of the employee...");
		Scanner scanner = new Scanner(System.in);
		String choice = scanner.nextLine(); // eg adfehd123497

		// properties file for log4j being used
		PropertyConfigurator.configure("resources\\log4j.properties");

		Properties p = new Properties();
		// Load the properties file
		try {
			p.load(new FileInputStream(new File(DB_CONN_FILE)));
		} catch (IOException e) {
			logger.debug("Error reading " + DB_CONN_FILE);
			e.printStackTrace();
			System.exit(-1);
		}
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		try (Connection conn = DriverManager.getConnection(p.getProperty("url"), p);) {
			// select data from test.attendance_log
			String sqlStmt = "SELECT test.attendance_log.card_id, test.attendance_log.time, test.attendance_log.code FROM test.attendance_log";
			Statement stmt = conn.createStatement();
			List<String> lines = new ArrayList<>();
			lines.add("card_id,time,code");

			ResultSet set = stmt.executeQuery(sqlStmt);
			try {
				System.out.println("Now displaying attendance for " + choice + "...");
				int counter = 0;
				while (set.next()) {
					counter++;
					// only entries matching the user inputed card_id will be displayed
					if (set.getString(1).equals(choice) && choice.length() == 12) {
						System.out.println(set.getString(1) + " " + set.getString(2) + " " + set.getString(3));
						lines.add(String.format("%s,%s,%s", set.getString(1), set.getString(2), set.getString(3)));
					}
				}

				logger.debug("Fetched " + counter + " rows.");
			} catch (SQLException e) {
				logger.debug("Query failed.");
				e.printStackTrace();
			}
			System.out.println("\nWould you like save to a CSV file? Enter 1 for yes.");

			String choice2 = scanner.nextLine();
			if (choice2.equals("1"))
				WritetoCSV.writeToFile(lines);
			else
				System.out.println("CSV file was not created...");
		}
	}
}