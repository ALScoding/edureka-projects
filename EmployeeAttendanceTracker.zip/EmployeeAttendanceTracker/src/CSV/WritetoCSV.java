package CSV;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

// all database table entries displayed in the console while HRprogramX.java is
// running will be written to a CSV file named results.csv

public final class WritetoCSV {

	public static void writeToFile(List<String> lines) {
		try (PrintWriter writer = new PrintWriter("resources/results.csv", "UTF-8")) {
			for (String line : lines)
				writer.println(line);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("File created or overwritten!");
	}
}
