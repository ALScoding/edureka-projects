package Multiclient;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

// run FileServer.java first before running FileClient.java otherwise an error will occur
// port number may need to be changed if it is already in use

public class FileServer {
	private static ServerSocket SS;
	private static FileInputStream FIS;

	public static void main(String[] args) throws Exception {
		final Logger logger = Logger.getLogger(FileServer.class.getName());

		// properties file for log4j being used
		PropertyConfigurator.configure("resources\\log4j.properties");

		try {
			System.out.println("Server running!");
			SS = new ServerSocket(2017);
			Socket sr = SS.accept();
			FIS = new FileInputStream("resources/results.csv");
			byte b[] = new byte[2002];
			FIS.read(b, 0, b.length);
			OutputStream os = sr.getOutputStream();
			os.write(b, 0, b.length);
		} catch (IOException e) {
			logger.error("Lost connection to host due to an I/O error.");
			e.printStackTrace();
		}
	}
}