package Multiclient;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

// running FileClient.java will allow the existing .csv file to be 'uploaded' to
// the server (the upload folder) while FileServer.java is already running

public class FileClient {

	private static Logger logger = Logger.getLogger(FileClient.class.getName());
	private static Socket St;
	private static FileOutputStream FOS;

	public static void main(String[] args) throws Exception {

		// properties file for log4j being used
		PropertyConfigurator.configure("resources\\log4j.properties");

		try {
			byte[] b = new byte[2002];
			St = new Socket("localhost", 2017);
			InputStream input = St.getInputStream();
			FOS = new FileOutputStream("upload/resultsfile.csv");
			input.read(b, 0, b.length);
			FOS.write(b, 0, b.length);
			System.out.println("File uploaded or overwritten!");
		} catch (UnknownHostException e) {
			logger.error("Could not connect to host.");
			e.printStackTrace();
		} catch (IOException e) {
			logger.error("Lost connection to host due to an I/O error.");
			e.printStackTrace();
		}
	}
}